# PLC Integration

## Barbieri Compass Servo Drive 2.0

API Endpoint: http://192.168.4.1:5000
Protocol: HTTP/JSON
Update Frequency: 5 seconds

